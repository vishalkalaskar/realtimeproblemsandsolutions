package com.fileupload.service;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadOnServerApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadOnServerApplication.class, args);
	}

}
