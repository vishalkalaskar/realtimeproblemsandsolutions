package com.example.auto;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class VerticalsidebarcollaspeApplicationTests {

	@Test
	void contextLoads() {
	}

}
