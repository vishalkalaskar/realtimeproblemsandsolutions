package com.example.auto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class VerticalsidebarcollaspeApplication {

	public static void main(String[] args) {
		SpringApplication.run(VerticalsidebarcollaspeApplication.class, args);
	}

}
