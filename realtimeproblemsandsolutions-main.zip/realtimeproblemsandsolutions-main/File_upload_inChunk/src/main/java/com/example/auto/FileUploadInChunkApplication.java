package com.example.auto;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class FileUploadInChunkApplication {

	public static void main(String[] args) {
		SpringApplication.run(FileUploadInChunkApplication.class, args);
	}

}
