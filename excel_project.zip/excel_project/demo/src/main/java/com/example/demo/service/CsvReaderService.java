package com.example.demo.service;

import java.io.File;
import java.io.FileInputStream;
import java.io.InputStream;
import java.util.*;

import org.apache.poi.openxml4j.opc.OPCPackage;
import org.apache.poi.poifs.filesystem.FileMagic;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Service;

@Service
public class CsvReaderService {

    public List<Map<String, String>> readExcel() {
        List<Map<String, String>> dataList = new ArrayList<>();
        String filePath = "C:\\Users\\vishalak.ttl\\Downloads\\server_dataone.xlsx"; // Set your file path

        try (InputStream fis = new FileInputStream(new File(filePath))) {
            Workbook workbook;

            // Detect file format using FileMagic
            InputStream bufferedStream = FileMagic.prepareToCheckMagic(fis);
            FileMagic fileMagic = FileMagic.valueOf(bufferedStream);

            if (fileMagic == FileMagic.OLE2) {
                workbook = new HSSFWorkbook(bufferedStream); // XLS (older format)
            } else if (fileMagic == FileMagic.OOXML) {
                workbook = new XSSFWorkbook(bufferedStream); // XLSX (newer format)
            } else {
                throw new IllegalArgumentException("Unsupported Excel file format.");
            }

            Sheet sheet = workbook.getSheetAt(0);
            Iterator<Row> rowIterator = sheet.iterator();

            // Read the header row
            if (!rowIterator.hasNext()) {
                throw new IllegalArgumentException("The Excel file is empty.");
            }
            Row headerRow = rowIterator.next();
            List<String> headers = new ArrayList<>();
            for (Cell cell : headerRow) {
                headers.add(cell.getStringCellValue());
            }

            // Read remaining rows
            while (rowIterator.hasNext()) {
                Row row = rowIterator.next();
                Map<String, String> rowData = new HashMap<>();
                for (int i = 0; i < headers.size(); i++) {
                    Cell cell = row.getCell(i, Row.MissingCellPolicy.CREATE_NULL_AS_BLANK);
                    rowData.put(headers.get(i), cell.toString());
                }
                dataList.add(rowData);
            }

            workbook.close();
        } catch (Exception e) {
            throw new RuntimeException("Failed to read the Excel file: " + e.getMessage(), e);
        }
        return dataList;
    }
}
