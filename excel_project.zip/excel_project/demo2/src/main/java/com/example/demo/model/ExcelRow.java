package com.example.demo.model;

import java.util.LinkedHashMap;
import java.util.Map;

public class ExcelRow {
    private Map<String, Object> cells = new LinkedHashMap<>();

    public void addCell(String header, Object value) {
        cells.put(header, value);
    }

    public Map<String, Object> getCells() {
        return cells;
    }
}
