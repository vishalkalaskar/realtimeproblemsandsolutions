package com.example.demo.service;

import com.example.demo.model.*;
import com.example.demo.model.ExcelRow;
import com.example.demo.service.*;
import org.apache.poi.ss.usermodel.*;
import org.apache.poi.xssf.usermodel.XSSFWorkbook;
import org.apache.poi.hssf.usermodel.HSSFWorkbook;
import org.springframework.stereotype.Service;
import org.springframework.web.multipart.MultipartFile;

import java.io.IOException;
import java.io.InputStream;
import java.util.ArrayList;
import java.util.List;

@Service
public class ExcelReaderService {

    private List<ExcelRow> allRows = new ArrayList<>();
    private List<String> headers = new ArrayList<>();

    public void processExcelFile(MultipartFile file) throws IOException {
        allRows.clear(); // Clear previous data
        headers.clear();

        try (InputStream inputStream = file.getInputStream()) {
            Workbook workbook;

            if (file.getOriginalFilename().endsWith(".xlsx")) {
                workbook = new XSSFWorkbook(inputStream);
            } else if (file.getOriginalFilename().endsWith(".xls")) {
                workbook = new HSSFWorkbook(inputStream);
            } else {
                throw new IllegalArgumentException("Invalid file format. Please upload an Excel file.");
            }

            Sheet sheet = workbook.getSheetAt(0);

            // Extract headers
            Row headerRow = sheet.getRow(0);
            for (Cell cell : headerRow) {
                headers.add(ExcelUtils.getCellValueAsString(cell));
            }

            // Extract all rows (store in memory)
            for (int i = 1; i <= sheet.getLastRowNum(); i++) {
                Row currentRow = sheet.getRow(i);
                if (currentRow == null) continue;

                ExcelRow excelRow = new ExcelRow();
                for (int j = 0; j < headers.size(); j++) {
                    Cell cell = currentRow.getCell(j);
                    excelRow.addCell(headers.get(j), cell != null ? ExcelUtils.getCellValueAsString(cell) : "");
                }
                allRows.add(excelRow);
            }

            workbook.close();
        }
    }

    public ExcelData getPaginatedData(int page, int size) {
        int start = page * size;
        int end = Math.min(start + size, allRows.size());
        List<ExcelRow> paginatedRows = allRows.subList(start, end);

        return new ExcelData(headers, paginatedRows);
    }

    public int getTotalRecords() {
        return allRows.size();
    }
}
