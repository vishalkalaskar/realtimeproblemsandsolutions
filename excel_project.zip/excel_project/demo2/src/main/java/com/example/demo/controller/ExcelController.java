package com.example.demo.controller;

import com.example.demo.model.*;
import com.example.demo.service.*;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;
import org.springframework.web.multipart.MultipartFile;

@RestController
@RequestMapping("/api/excel")
@CrossOrigin(origins = "*") // Allow frontend requests
public class ExcelController {

    @Autowired
    private ExcelReaderService excelReaderService;

    @PostMapping("/upload")
    public ResponseEntity<?> uploadExcel(@RequestParam("file") MultipartFile file) {
        if (file.isEmpty()) {
            return ResponseEntity.badRequest().body("Please select an Excel file to upload.");
        }

        try {
            excelReaderService.processExcelFile(file);
            return ResponseEntity.ok("File processed successfully. Total records: " + excelReaderService.getTotalRecords());
        } catch (Exception e) {
            return ResponseEntity.badRequest().body("Error processing file: " + e.getMessage());
        }
    }

    @GetMapping("/data")
    public ResponseEntity<ExcelData> getPaginatedData(
            @RequestParam(defaultValue = "0") int page,
            @RequestParam(defaultValue = "100") int size) {
        return ResponseEntity.ok(excelReaderService.getPaginatedData(page, size));
    }

    @GetMapping("/total-records")
    public ResponseEntity<Integer> getTotalRecords() {
        return ResponseEntity.ok(excelReaderService.getTotalRecords());
    }
}
