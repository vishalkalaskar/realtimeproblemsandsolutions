package com.example.demo.model;

import java.util.List;

public class ExcelData {
    private List<String> headers;
    private List<ExcelRow> rows;

    public ExcelData(List<String> headers, List<ExcelRow> rows) {
        this.headers = headers;
        this.rows = rows;
    }

    public List<String> getHeaders() {
        return headers;
    }

    public List<ExcelRow> getRows() {
        return rows;
    }
}
