let currentPage = 0;
const pageSize = 100;
let totalRecords = 0;

function uploadFile() {
    let fileInput = document.getElementById("fileInput");
    if (!fileInput.files.length) {
        alert("Please select a file!");
        return;
    }

    let file = fileInput.files[0];
    let formData = new FormData();
    formData.append("file", file);

    fetch("http://localhost:8083/api/excel/upload", {
        method: "POST",
        body: formData
    })
    .then(response => response.text())
    .then(message => {
        alert(message);
        fetchTotalRecords();
    })
    .catch(error => alert("Error: " + error));
}

function fetchTotalRecords() {
    fetch("http://localhost:8083/api/excel/total-records")
    .then(response => response.json())
    .then(data => {
        totalRecords = data;
        loadPage(0);
    })
    .catch(error => console.error("Error fetching total records:", error));
}

function loadPage(page) {
    fetch(`http://localhost:8083/api/excel/data?page=${page}&size=${pageSize}`)
    .then(response => response.json())
    .then(data => {
        displayData(data.headers, data.rows);
        currentPage = page;
        updatePagination();
    })
    .catch(error => console.error("Error fetching paginated data:", error));
}

function displayData(headers, rows) {
    let headerHtml = "<tr>" + headers.map(header => `<th>${header}</th>`).join("") + "</tr>";
    let bodyHtml = rows.map(row => 
        "<tr>" + headers.map(header => `<td>${row.cells[header] || ''}</td>`).join("") + "</tr>"
    ).join("");

    document.getElementById("table-header").innerHTML = headerHtml;
    document.getElementById("table-body").innerHTML = bodyHtml;
}

function updatePagination() {
    let totalPages = Math.ceil(totalRecords / pageSize);
    let paginationHtml = `<button class="btn btn-secondary mr-2" onclick="loadPage(0)" ${currentPage === 0 ? "disabled" : ""}>First</button>`;
    
    paginationHtml += `<button class="btn btn-secondary mr-2" onclick="loadPage(${currentPage - 1})" ${currentPage === 0 ? "disabled" : ""}>Prev</button>`;

    paginationHtml += `<span> Page ${currentPage + 1} of ${totalPages} </span>`;

    paginationHtml += `<button class="btn btn-secondary ml-2" onclick="loadPage(${currentPage + 1})" ${currentPage >= totalPages - 1 ? "disabled" : ""}>Next</button>`;

    paginationHtml += `<button class="btn btn-secondary ml-2" onclick="loadPage(${totalPages - 1})" ${currentPage >= totalPages - 1 ? "disabled" : ""}>Last</button>`;

    document.getElementById("pagination-controls").innerHTML = paginationHtml;
}
